# otel-demo
Golang otel-demo

```
make run
```
